#____________________________________________________
print()
print("Lambda Function")
print("----------------------------------------------")
#----------------------------------------------------
sum = lambda x,y:x+y
square= lambda x:x**2
print("Sum is:",sum(10,20))
print("Square is:",square(30))
print("The type lambda function returns:",type(sum))
#____________________________________________________
print()
print("Filter Function")
print("----------------------------------------------")
#----------------------------------------------------
l = [10,15,20,25,30,35,40]
varFilter = filter(lambda x:x%2==0,l)
for element in varFilter:
    print(element,end='\t')
print()
print("Type of filter function return",type(varFilter))
#____________________________________________________
print()
print("Reduce Function")
print("----------------------------------------------")
#----------------------------------------------------
from functools import reduce
l1 = [10,15,20,25,30,35,40.0]
varReduce = reduce(lambda x,y:x+y,l1)
print(varReduce)
print("Type of reduce function return",type(varReduce))

print()
print("Map Function")
print("----------------------------------------------")
#----------------------------------------------------
l=[10,20,30,40,50]
mapSquare = map(lambda x:x**2, l)
for element in mapSquare:
	print(element,end='\t')
print()	
l=[10,20,30,40,50]
l2 = [45,50,55,60]
mapSquare = map(lambda x,y:x+y, l,l2)
for element in mapSquare:
	print(element,end='\t')
print()
print("Type of map function return",type(mapSquare))
#____________________________________________________