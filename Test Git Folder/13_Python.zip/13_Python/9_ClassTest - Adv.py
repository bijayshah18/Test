#1. Multiple Inheritance
#2. Hierarchical Inheritance
#3. Multi level Inheritance
#4. Hybrid Inheritance

#1. Abstraction # Hiding complexity. Variable staring with double underscore (__) not accessible through object; can only be accessed through method of the class.
#2. Encapsulation # Hiding data. PL which works classes & objects concept
#3. Inheritance # 
#4. Polymorphism (Method overloading and overriding)--> Practically method overloading not possible; though theoretically possible.

#Class example # Every user defined class inherits Object class which is present in __builtins__ module
class Employee:
    __a=10
    def __init__(self,empName,empId,empSal,empAddr):
        self.empName = empName
        self.empId = empId
        self.empSal = empSal
        self.empAddr = empAddr
    def display(self):
        print("Employee Name:\t\t",self.empName)
        print("Employee Id:\t\t",self.empId)
        print("Employee Salary:\t",self.empSal)
        print("Employee Address:\t",self.empAddr)
        print("variable value:",self.__a)
		
emp1 = Employee("Vijay",201359,9000.0,"Kolkata")
emp2 = Employee("Abhishek",421431,8000.0,"Bhubaneswar")
print("First employee details:")
print("------------------------")
emp1.display()
#print(emp1.__a)
print("Second employee details:")
print("------------------------")
emp2.display()
#print(emp2.__a)
#=====================================================================
print("------------------------")
print("Inheritance:")
print("------------------------")
class A:
    def __init__(self):
	    print("Inside Class A constructor")
    def display(self):
        print("Inside class A display method")
    def displayA(self):
        print("Inside displayA method")

class B(A):
    def __init__(self):
	    print("Inside Class B constructor")
    def display(self):
        print("Inside class B display method")
    def displayB(self):
        print("Inside displayB method")

class C(A):		
    def __init__(self):
        print("Inside class C constructor")
    def display(self):
        print("Inside class C display method")
    def displayC(self):
        print("Inside displayC method")
		
class D(B,C):
    def __init__(self):
        print("Inside class D constructor")
    def display(self):
        print("Inside class D display method")
    def displayD(self):
        print("Inside displayD method")
		
obj1 = A()
obj2 = B()
obj3 = C()
obj4 = D()
print()
obj1.display()
obj2.display()
obj3.display()
obj4.display() ##
print()
obj2.displayA()
obj2.displayB()
print()
obj3.displayA()
obj3.displayC()
print()
obj4.displayA() ##
obj4.displayB()
obj4.displayC()
obj4.displayD()
print("#==============================================================================#")
#Variable types for class in python and how to access them
#1. Static or Class level variable --> Can be accessed using class name (inside class and outside class both) and using reference variable outside the class.
#2. Non-static or Object / Instance / Reference variable --> Can be accessed using 'self' keyword inside the class and using reference variable outside class.
#3. Local or method level variable --> Available whenever a method call is made.


class Employee:
    __a=10 # If a static variable starts with double underscore, it cannot be accessed from outside class using class name or reference variable name
    b=20# Static variables
    def __init__(self,empName,empId,empSal,empAddr): # Non-static variables
        self.empName = empName
        self.empId = empId
        self.empSal = empSal
        self.empAddr = empAddr
    def display(self):
        print("Accessing Non-static variables from inside class:",self.empName, self.empId)
        print("Employee Name:\t\t",self.empName)
        print("Employee Id:\t\t",self.empId)
        print("Employee Salary:\t",self.empSal)
        print("Employee Address:\t",self.empAddr) #print("variable value:",self.__a)
        print("Accessing static variables from inside class:",Employee.__a,Employee.b)
e1 = Employee("Vijay",201359,10000,"Kolkata")		
print("Accessing Non-static variables from outside class:",e1.empName, e1.empId)
e1.display()
print("Accessing static variables from outside class:", Employee.b,e1.b)
#print("Accessing static variables from outside class:",e1.__a, Employee.__a) # Gives error
