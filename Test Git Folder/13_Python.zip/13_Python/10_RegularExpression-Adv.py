#Regular Expression:- re module

#methods #m.start(), m.end(),m.group()
match()
fullmatch()

search()

findall()
finditer()

sub()
subn()

#Quantifiers
a  --> exactly one a
a+ --> One or more a
a* --> Zero or more a
a? --> zero or one a
a{m} --> exactly m number of a
a{m,n} --> minimum m a to maximum n a  

#Character classes
[a-zA-Z0-9] --> alpha numeric character
[^a-zA-Z0-9] --> except alpha numeric character

\s --> Space character
\S --> Non space character
\d --> Any digit // Same as [0-9]
\D --> Non digit // Same as [^0-9]
\w --> word character // Same as [a-zA-Z0-9] --> alpha numeric character
\W --> Non word character // Same as [^a-zA-Z0-9] --> except alpha numeric character
. --> any character


^a --> begins with a
a$ --> ends with a
a|b  --> a or b