#------------------------------------------------
print("Ternary operator:")
print("-----------------")
#------------------------------------------------
a,b=1,2
x=10 if a<b else 20
print(x)
#------------------------------------------------
print("List Comprehension:")
print("-----------------")
#------------------------------------------------
l = [10,15,30,45,50,60]
lstCompre = [float(x) for x in l if x%2==0]
print(lstCompre)
print(type(lstCompre))
#------------------------------------------------
print("Set Comprehension:")
print("-----------------")
#------------------------------------------------
s= {10,12,11,13,14}
setCompre = {x for x in s if x%2!=0}
print(setCompre)
print(type(setCompre))
#------------------------------------------------
print("Tuple Comprehension:") #Not possible in python because it produces generator class
print("-----------------")
#------------------------------------------------
s= {10,12,11,13,14}
setCompre = (x for x in s if x%2!=0)
for x in setCompre:
    print(x,end='\t')
print()
print(type(setCompre))
#------------------------------------------------
print("Dictionary Comprehension:")
print("-------------------------")
#------------------------------------------------
dictCompre = {x:x**2 for x in range(10) if x%2==0}
print(dictCompre)
print(type(setCompre))
print()
cities = ['Kolkata','Dhaka','New York','Berlin']
countries = ['India','Bangladesh','US','Germany']
z= zip(cities,countries)
print("Type of zip() function:",type(z))
for item in z:
    print(item,'\t')
dictCompre2 = {city:country for (city,country) in zip(cities,countries)}
print(dictCompre2)
#------------------------------------------------












