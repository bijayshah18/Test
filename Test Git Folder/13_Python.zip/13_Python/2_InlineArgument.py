#from sys import argv
import sys

print(dir(sys))
help(sys)

print(sys.argv[1])