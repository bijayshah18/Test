import math
from random import *

print("random():",random())
print("randint(a,b):",randint(10,20))
print("randrange(a,b):",randrange(10,20))
print("uniform(a,b):",uniform(10,20))
print("choice():",choice((10,20,30,40)))
print("choice():",choice([10,20,30,40]))
#print("choice function returns an element from given sequence3:",choice({10,20,30,40)})
