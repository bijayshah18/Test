Two types of assert statement
1. Simple (e.g. assert conditional_statement)
2. Augmented (e.g. assert conditional_statement, "message")


Java Stack:- https://stackoverflow.com/questions/9588827/how-to-switch-to-the-new-browser-window-which-opens-after-click-on-the-button

Intro to Azure DevOps:- https://www.youtube.com/watch?v=H-R2bCXfz8I
Setting Up a GitHub Repository:- https://www.youtube.com/watch?v=TDuG1WU3GvM
Selenium with Python (Advanced) :- https://www.youtube.com/watch?v=IYILCEV5j6s&list=PLUDwpEzHYYLvx6SuogA7Zhb_hZl3sln66

XPath:- https://www.youtube.com/watch?v=3uktjWgKrtI

performance testing tools-->?

taskkill /F /IM iexplore.exe
taskkill /F /IM chrome.exe

