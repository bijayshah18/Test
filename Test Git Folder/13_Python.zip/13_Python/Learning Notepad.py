#------------------------------------------------------------------
#n= int(input("Enter some number:"))
#for x in range(1,n+1):
#    for y in range(1,x+1):
#        print("*",end=' ')
#    print()
#------------------------------------------------------------------
#n= int(input("Enter some number:")) #Prints triangle
#for i in range(1,n+1):
#     print("* "*i)
#------------------------------------------------------------------
#n= int(input("Enter some number:")) #Prints square
#for i in range(1,n+1):
#     print("* "*n)
#------------------------------------------------------------------
#s= int(input("Enter some string:"))
#print(sorted(s))
#------------------------------------------------------------------#------------------------------------------------------------------
#s=input("Enter some string:") #==> To reverse a string
#print("Reversed String:",s[::-1])
#------------------------------------------------------------------
#s=input("Enter some string:") #To reverse a string
#l = len(s)
#for i in range(l-1,-1,-1):
#    print(s[i],end='')
#------------------------------------------------------------------
#s=input("Enter some string:") #==> To reverse the content of each word of a string
#l=s.split()
#for item in l:
#    print(item[::-1],end=' ')
#------------------------------------------------------------------    
#s = input("Enter some string:") # To find each vowel count present in a string
#vowel = {'a','e','i','o','u'}
#d={}
#for x in s:
#    if x in vowel:
#       d[x] = d.get(x,0) + 1
#print(d)
#------------------------------------------------------------------    
#s = input("Enter some string:") # To find each letter count present in a string
#d={}
#for x in s:
#    d[x]= d.get(x,0)+1
#for k,v in d.items():
#    print("{} is present {} times in the given string.".format(k,v))
#------------------------------------------------------------------    
#s = input("Enter some string:") # To find the vowels present in a string
#v = set()
#vowel = {'a','e','i','o','u'}
#for x in s:
#    if(x in vowel):
#	    v.add(x)
#print("Vowels present in the string are:{}".format(v))
#------------------------------------------------------------------#------------------------------------------------------------------
#s=input("Enter some string:")
#l = len(s)
#for i in range(l):
#    print(s[i])
#------------------------------------------------------------------
#s=input("Enter some string:")
#for x in s:
#    print(x,end='')
#------------------------------------------------------------------
#list=[x**2 for x in range(1,11) if x%2==0] ## List comprehension
#print(list)
#print(type(list))
#------------------------------------------------------------------
#tup1 = (5,)
#tup2 = (10,20,30)
#print("Type is:",type(tup1),"And value is:",tup1)
#print("Type is:",type(tup2),"And value is:",tup2)
#------------------------------------------------------------------
#tup1=(10,20,30)
#tup2=(10,20,30)
#print("Type is:",type(tup1),"Address is:",id(tup1),"And value is:",tup1)
#print("Type is:",type(tup2),"Address is:",id(tup2),"And value is:",tup2)
#print("Equality check:",tup1 == tup2)

#tup3=(x*x for x in range(1,11)) ## Tuple comprehension not possible; can be achieved via generator class
##list = list(tup3)
#print("Type is:",type(tup3),"Address is:",id(tup3),"And value is:",tup3)

#for x in tup3: 
#    print(x,end=' ')
##print("Converted list from tuple:",list)
#------------------------------------------------------------------
#t1=(20,10,30,70,50,60,30,40)
#print("Input Tuple:",t1)
#l1= sorted(t1)
#l2= sorted(t1,reverse=True)
#print("Sorted List in ascending order:",l1)
#print("Sorted List in descending order:",l2)
#print("Min from input tuple:",min(t1))
#print("Max from input tuple:",max(t1))
#print()
#print("Count of 30 in input tuple:",t1.count(30))
#print("Length of input tuple:",len(t1))
#print("First index of 30 in input tuple:",t1.index(30))
#print()
#print("Clone of input tuple:",t1.copy())
#------------------------------------------------------------------
#l = [eval(x) for x in input("Enter some numbers:").split(",")]
#print("You entered:",l)
#------------------------------------------------------------------
#n= int(input("Enter some number:")) #Prints triangle
#for x in range(1,n+1):
#    for y in range(1,x+1):
#        print("*",end=' ')
#    print()
#------------------------------------------------------------------
#n= int(input("Enter some number:")) #Prints triangle
#for i in range(1,n+1):
#     print("* "*i)
#------------------------------------------------------------------
#n= int(input("Enter some number:")) #Prints square
#for i in range(1,n+1):
#     print("* "*n)
#------------------------------------------------------------------
#s= int(input("Enter some string:"))
#print(sorted(s))
#------------------------------------------------------------------
#l1= eval(input("Enter list 1:"))
#l2= eval(input("Enter list 2:"))
#print("List 1:",l1)
#print("List 2:",l2)
#l1.append(100)
#print("Appended list 1:",l1)
#------------------------------------------------------------------
#s=input("Enter some string:")
#l = len(s)
#for i in range(l):
#    print(s[i])
#------------------------------------------------------------------
#s=input("Enter some string:")
#for x in s:
#    print(x,end='')
#------------------------------------------------------------------
#s=input("Enter some string:") #Reverses tring
#l = len(s)
#for i in range(l-1,-1,-1):
#    print(s[i],end='')
#------------------------------------------------------------------
#tup1 = (5,)
#tup2 = (10,20,30)
#print("Type is:",type(tup1),"And value is:",tup1)
#print("Type is:",type(tup2),"And value is:",tup2)
#------------------------------------------------------------------
#t1=(20,10,30,70,50,60,30,40)
#print("Input Tuple:",t1)
#l1= sorted(t1) #==> To sort the content of tuple
#l2= sorted(t1,reverse=True) #==> To sort the content of tuple in descending order
#print("Sorted List in ascending order:",l1)
#print("Sorted List in descending order:",l2)
#print("Min from input tuple:",min(t1))
#print("Max from input tuple:",max(t1))
#print()
#print("Count of 30 in input tuple:",t1.count(30))
#print("Length of input tuple:",len(t1))
#print("First index of 30 in input tuple:",t1.index(30))
#print()
#print("Clone of input tuple:",t1.copy())
#------------------------------------------------------------------
#l = [eval(x) for x in input("Enter some numbers:").split(",")]
#print("You entered:",l)
#------------------------------------------------------------------
#l1= eval(input("Enter list 1:"))
#l2= eval(input("Enter list 2:"))
#print("List 1:",l1)
#print("List 2:",l2)
#l1.append(100)
#print("Appended list 1:",l1)
#------------------------------------------------------------------
#s=input("Enter some string:")
#l = len(s)
#for i in range(l):
#    print(s[i])
#------------------------------------------------------------------
#s=input("Enter some string:")
#for x in s:
#    print(x,end='')
#------------------------------------------------------------------
#list=[x**2 for x in range(1,11) if x%2==0] ## List comprehension
#print(list)
#print(type(list))
#------------------------------------------------------------------
#tup1 = (5,)
#tup2 = (10,20,30)
#print("Type is:",type(tup1),"And value is:",tup1)
#print("Type is:",type(tup2),"And value is:",tup2)
#------------------------------------------------------------------
#tup1=(10,20,30)
#tup2=(10,20,30)
#print("Type is:",type(tup1),"Address is:",id(tup1),"And value is:",tup1)
#print("Type is:",type(tup2),"Address is:",id(tup2),"And value is:",tup2)
#print("Equality check:",tup1 == tup2)

#tup3=(x*x for x in range(1,11)) ## Tuple comprehension not possible; can be achieved via generator class
##list = list(tup3)
#print("Type is:",type(tup3),"Address is:",id(tup3),"And value is:",tup3)

#for x in tup3: 
#    print(x,end=' ')
##print("Converted list from tuple:",list)
#------------------------------------------------------------------
#t1=(20,10,30,70,50,60,30,40)
#print("Input Tuple:",t1)
#l1= sorted(t1)
#l2= sorted(t1,reverse=True)
#print("Sorted List in ascending order:",l1)
#print("Sorted List in descending order:",l2)
#print("Min from input tuple:",min(t1))
#print("Max from input tuple:",max(t1))
#print()
#print("Count of 30 in input tuple:",t1.count(30))
#print("Length of input tuple:",len(t1))
#print("First index of 30 in input tuple:",t1.index(30))
#print()
#print("Clone of input tuple:",t11.copy())
#------------------------------------------------------------------
#l1=[100,20,30,90,70,80,60,50,60,50,30]
#print("Input List:",l1)
#l1.sort()
#print("Sorted List in ascending order:",l1)
#l1.sort(reverse=True)
#print("Sorted List in descending order:",l1)
#print()
#print("Length of input list:",len(l1))
#print("Count of 50 in the input list:",l1.count(50))
#print("Index of first 50 in the input list sorted in descending:",l1.index(50))
#print()
#l2=l1.copy()
#print("Original list after copy:",l1)
#print("Cloned copy:",l2)
#print()
#l1.remove(50)
#print("Original list after removing 50:",l1)
#print()
#a=l1.pop()
#b=l1.pop(0)
#print("Original list after calling pop function:",l1,"And popped values are:",a,b)
#print()	
#l1.clear()
#print("Original list after calling clear function:",l1)
#print("Cloned list after calling pop function:",l2)
#print()
#l1.append(10)
#l1.append('Vijay')
#print("Original list after calling clear & append functions:",l1)
#print()
#l2.extend(l1)
#print("Cloned list after calling extend function:",l2)
#print("Original list:",l1)
#print()
#l1.append('Sah')
#print("Original list after append:",l1)
#l1.insert(2,'Kumar')
#print("Original list after 2nd append:",l1)
#print("Min & Max:")
#l2.pop()
#print("Minimum:",min(l2))
#print("Maximum:",max(l2))
#------------------------------------------------------------------
#l=[[10,20,30],[40,50,60],[70,80,90]]
#print(l)
#for r in l:
#    print(r)
#------------------------------------------------------------------
#l=[[10,20,30],[40,50,60],[70,80,90]]
#print("Input list:-",l)
#print("Output in matrix format:-")
#for i in range(len(l)):
#    for j in range(len(l[i])):	
#	    print(l[i][j],end=' ')
#    print()
#------------------------------------------------------------------    
#l1=[10,20,30]
#l2=[40,50,60]
#l3=l1 + l2
#print(l3)
#print(l3*2)
#------------------------------------------------------------------    
#l1=[40,50,60]
#l2=[40,50,60,70]
#print("l1 = l2:", l1 == l2)
#print("l1 < l2:", l1 < l2)
#print("l1 <= l2:", l1 <= l2)
#print("l1 > l2:", l1 > l2)
#print("l1 >= l2:", l1 >= l2)
#------------------------------------------------------------------    
#l1=(40,50,60)
#l2=(40,50,60,70)
#print("l1 = l2:","\t", l1 == l2)
#print("l1 < l2:","\t", l1 < l2)
#print("l1 <= l2:","\t", l1 <= l2)
#print("l1 > l2:","\t", l1 > l2)
#print("l1 >= l2:","\t", l1 >= l2)
#------------------------------------------------------------------    
#d1 = eval(input("Enter some dictionary:"))
#sum=0
#for x in d1.values():
#    sum = sum + x
#print("The sum is:{}".format(sum))
#------------------------------------------------------------------    
#d1= eval(input("Enter some dictionary:"))	
#print("The sum is:{}".format(sum(d1.values())))
#------------------------------------------------------------------    
#d= {'A':100,'B':200,'C':400}
#d1=d.copy()
#print("Cloned dictionary:",d1)
#d1.update({'a':'Apple','b':'Banana'})
#print("Updated dictionary is:",d1)
#print("Get item from dictionary which is present in dictionary:",d1.get('A'))
#print("Get item from dictionary which is not present in dictionary:",d1.get('c'))
#print("Get default value from dictionary for an item which is not present in dictionary:",d1.get('c','Cat'))
#print("Get/set default value from/to dictionary for an item which is not present in dictionary:",d1.setdefault('c','Cat'))
#print("Updated dictionary after setdefault",d1)
#del d1['c']
#print("Dictionary after deleting an item:",d1)
#print("Popped value from dictionary:",d1.pop('b'))
#print("Dictionary after popping an item:",d1)
#print("Randomly popped value from dictionary:",d1.popitem())
#print("Dictionary after popping an item:",d1)
#d1.clear()
#print("Dictionary after applying clear function:",d1)
#del d1
#print("Dictionary after deleting:",d1)
#------------------------------------------------------------------    
#d = {'A': 100, 'B': 200, 'C': 400, 'a': 'Apple', 'b': 'Banana', 'c': 'Cat'}
#print("All the keys of dictionary are:")
#for x in d.keys():
#    print(x,end=' ')
#print()
#print("Another way of getting keys is:",d.keys())
#print()
#print("All the values of the dictionary are:")
#for x in d.values():
#    print(x, end=' ')
#print()
#print("Another way of getting values is:",d.values())
#print()
#print("All the items of the dictionary are:")
#for x in d.items():
#    print(x, end=' ')
#print()
#print("Another way of getting items is:",d.items())
#------------------------------------------------------------------    
#s1 = {10,20,30,40}		
#s2 = {30,40,50,60}
#l = ['Apple','Banana']
#t = ('Cat','Dog')
#print("Before pop function:",s1)
#s1.pop()
#print("After pop function:",s1)
#s1.add(100)
#print("After add function:",s1)
#s1.update(s2,l,t)
#print("After update function with set,list and tuple:",s1)
#------------------------------------------------------------------    
#s1 = {10,20,30,40}		
#s2 = {30,40,50,60}
#print("s1 union s2:",s1.union(s2))
#print("s1 intersection s2:",s1.intersection(s2))
#print("s1 minus s2:",s1 - s2)
#print("s2 minus s1:",s2 - s1)
#print("s1 ^ s2:",s1^s2) 			#?
#------------------------------------------------------------------    
#d1 = dict([(10,'Apple'),(20,20),(30,True),(40,40.40),(50,50+5j)])
#print("Dictionary from list of tuples",d1)
#d2 = dict({(10,'Apple'),(20,20),(30,True),(40,40.40),(50,50+5j)})
#print("Dictionary from set of tuples",d2)
#d3 = dict(((10,'Apple'),(20,20),(30,True),(40,40.40),(50,50+5j)))
#print("Dictionary from tuple of tuples",d3)
#print()
#d4 = {1:'Apple','B':'Banana',True:'Cat',1.0:'Dog',(10):'Elephant'} ##Only valid key types are int,str& tuple
#print(d4)		# With bool and float as the key it will not throw any error but item will not be added into dict
		# With list, set and dict as the key it will throw - TypeError: unhashable type: 'list'/'set/'dict'		
#------------------------------------------------------------------    	
#lambda
#a=100
#b=20
#greater = lambda a,b:a if a>b else b
#print("The greater number is:",greater(a,b))
#------------------------------------------------------------------    	
#filter()
#l1 = [10,20,25,30,35]
#l2=[]
#l2 = filter(lambda x:x%2==0,l1)
#print(type(l2))
#for x in l2:
#    print(x,end=' ')
#------------------------------------------------------------------    	
#map()
#l1 = [10,20,25,30,35]
#l2=[]
#l2 = map(lambda x:x**2,l1)
#print(type(l2))
#for x in l2:
#    print(x,end=' ')
#------------------------------------------------------------------    	
#reduce()
#from functools import *
#l1 = [10,20,25,30,35]
#l2 = reduce(lambda x,y:x+y,l1)
#print(type(l2))
#print (l2)
#------------------------------------------------------------------    	
#l1=(10,20,30,40,50)
#l2=(x*2 for x in l1) #<class 'generator'>
#print(type(l2))
#for x in l2:
#    print(x,end=' ')
#------------------------------------------------------------------    	
#d1 = {10:'Apple',20:'Banana',30:'Cat'}
#d2 = []
#d2 = [x for x in d1.items()]
#print(type(d2))
#print(d2)
#------------------------------------------------------------------    	
#nested function
#def f1():
#	print("Inside outer function")
#	def inner():
#		print("Inside inner function")
#	print("Exiting outer function")
#	return inner
#f1()
#f=f1()
#f()
#------------------------------------------------------------------    	
#decorator function
#def smartDivide(divide)	:
#	def inner(a,b):
#		if(b==0):
#			print("Division by zero not possible")
#		else:
#			return divide(a,b)
#	return inner
	
#@smartDivide #By annotating the original function this way, whenever called using 'divide(10,20)' decorated function will get the call always
#def divide(a,b):	
#    return a/b

#decorFunction = smartDivide(divide) #By this way, both original and annotated function can be called as per need

#print(divide(10,20)) #Call original divide() function
#print()
#print(decorFunction(10,20)) #Call decorated function
#print(decorFunction(10,0)) #Call decorated function
#_____________________________________________________________________________________
#--------------------------------------------------------------------------
#dir() #members of current module
#dir(dirname) #members of desired module
# Default members added by python to a module are:- __builtins__,__cached__,__doc__,__file__,__loader__,__name__,__package__
# if __name__ =='__main__'==> The module containing the code is executed directly as a program otherwise the code is executed indirectly as a module from some other program

#from imp import reload # To reload a module again; by default a module is loaded only once at the time of first import, but not reloaded again even if 2nd import is done
#from math import *
#from random import *
#help (math)
#random()
#randint()
#uniform()
#randrange()
#choice()
#_____________________________________________________________________________________
#import Module1
#if __name__ == "__main__":
#	print("I am in test module")
#	print("__name__ in test module:-",__name__)
#_____________________________________________________________________________________

class Employee:
	def __init__(self,name,id,salary):
		self.name = name
		self.id = id
		self.salary = salary	
	def display(self):
		print("Name:",self.name)
		print("Id:",self.id)
		print("Salary:",self.salary)		
emp1=Employee("Vijay",201359,1000.12)
emp1.display()
#___________________________________________________________________________
#---------------------------------------------------------------------------
#Web scrapping
import urllib.request
import request.urlopen

#___________________________________________________________________________
#---------------------------------------------------------------------------
Pickling and Unpickling
f = open("abc.text",'r')
f.read()
#___________________________________________________________________________
#---------------------------------------------------------------------------
Threading can be achieved in 3 ways in Python
a. Without using any class
--------------------------
from threading import *
def display():
    print("This code executed by thread:",current_thread.getName())
	
t = Thread(target = display) # MainThread creates child thread object
t.start() #MainThread starts child thread object
print("This code executed by thread:",current_thread.getName())

b. By extending Thread class 
-----------------------------
from threading import *
class MyThread(Thread):
    def run(self):
	    print("This code executed by thread:",current_thread.getName())

t = Thread()
t.start()
print("This code executed by thread:",current_thread.getName())

c. Without extending Thread class
---------------------------------
from threading import *
class Test:
    def display():
	    print("This code executed by thread:",current_thread.getName())
		
obj = Test()
t = Thread(target = obj.display)
t.start()
print("This code executed by thread:",current_thread.getName())
#___________________________________________________________________________
#---------------------------------------------------------------------------



