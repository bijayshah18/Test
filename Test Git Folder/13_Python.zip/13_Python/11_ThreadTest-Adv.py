#from threading import *
#def display():
#    print("This line executed by thread:",current_thread().getName())
#t = Thread(target=display)
#t.start()
#print("This line executed by thread:",current_thread().getName())
##########################################################################
from threading import * 													#### without extending Thread class
class Test:
    def display(self):
        print("This line executed by thread:",current_thread().getName())

#obj = Test()
t = Thread(target = Test().display)
t.start()
print("This line executed by thread:",current_thread().getName())
###########################################################################
#from threading import * 													#### by extending Thread class
#class Test(Thread):
#    def run(self):
#	    print("This line executed by thread:",current_thread().getName())
#t = Test()
#t.start()
#print("This line executed by thread:",current_thread().getName())
