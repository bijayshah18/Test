DB operation
To install cx_Oracle:- pip install cx_Oracle from cmd
To know the version:- con.version

1. Import cx_Oracle / pymysql
2. Create connection object like con = cx_Oracle.connect(id/password@localhost)
3. Create cursor object to handle records like cursor = con.cursor()
4. cursor.execute(query)  --> To execute a single query
   cursor.executescript(query) --> To execute a group/string of query separated by semicolon
   cursor.executemany(query)   --> To execute a parameterized query
5. cursor.fetchone()
   cursor.fetchall()
   cursor.fetchmany(n)   
6. commit()  # In python autocommit is not enabled by default
   rollback()
7. Close resources
   cursor.close()
   con.close()
#___________________________________________________________________________
#---------------------------------------------------------------------------