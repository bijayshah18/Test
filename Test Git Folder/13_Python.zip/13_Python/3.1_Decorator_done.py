def decorDivide(divide):
    def inner(a,b):
        if(b==0):
            return "Sorry!! Division by zero not possible."
        else:
            return divide(a,b)
    return inner
	
#@decorDivide
def divide(a,b):
    return a/b

print("Division Result:",divide(10,20))

decorFunc = decorDivide(divide)
print("Division Result:",decorFunc(10,0))

