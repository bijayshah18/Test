# 1. Default and Non-default argument
# 2. Keyword and Non-Keyword argument (Positional argument)
# 3. Variable-length argument (var tuple / var dict)

# Local vs Global variable

print("==============Default and Non-default && Keyword and Non-Keyword==============================")
#def add(a,b=20): #Default vs Non-default;; default argument should always follow Non-default argument otherwise 'SyntaxError: non-default argument follows default argument' is received.
def add(a,b):
    return (a+b)

#print(add(10,b=200))#Keyword vs Non-keyword;; Keyword argument should always follow Non-keyword argument otherwise 'SyntaxError: positional argument follows keyword argument' is received.
print(add(a=10,b=20))


print("======================================Var tuple Argument=======================================")
#def myFunc(*a): # Single star (*) signifies that the parameter is a tuple; function call can be done like - myFunc(10) or myFunc(10,20)...
#def myFunc(x,*a): #var tuple vs Non-default; var tuple should always follow Non-default argument if function called using Non-Keyword argument
def myFunc(*a,x): #var tuple vs Non-default; if Non-default argument follows var tuple then function should be called using Keyword argument always
    print(x)
    print(a)
	
#myFunc(10,20,30) #function called using Non-Keyword argument
myFunc(10,20,x=30) #function called using Keyword argument

print("======================================Var dict Argument=========================================")
def myFunc2(**a): # Double star (**) signifies that the parameter is a dict; function call should always be made using Keyword argument.
#def myFunc2():
    print(a)
	
myFunc2(a=10)
myFunc2(a=10,b=20,c=30,d=40)

print("===================================Local and Global variable====================================")
a = 1000
b = 2000
def f1():
    global a # If this line is omitted, a in the following line will be considered local variable for f1(), and hence changes made to this will not be available in f2()
    a = 1001
    c=3000
    print(a,b,c)
	#print(d) # error because d is local variable to f2()
def f2():
    d=4000
    print(a,b,d)
    #print(c) # error because c is local variable to f1()
f1()
f2()
print("===================================Recursive Function====================================")
n = int(input("Enter a number:"))

def fact_func(n):
    if (n == 1):
        return 1
    else:
        return (n*fact_func(n-1))
		
print("Factorial of {} is: {}".format(n,fact_func(n)))