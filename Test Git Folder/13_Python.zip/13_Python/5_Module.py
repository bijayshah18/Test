import random
import math
if __name__ == "__main__":
	print("I am in module1")
	print("__name__ in module1:-",__name__)
	
	print(dir())
	print(dir(random))
	print(dir(math))
	print(help(math))