import pickle
with open("PickleUnpickleTest.txt","r") as f:    
	print("Cursor position before read function:",f.tell())
	print(f.read())
	print("Cursor position before readlines function:",f.tell())
	f.seek(0)
	print(f.readlines())
	print("Cursor position before readlines function through iteration:",f.tell())
	f.seek(0)
	lines = f.readlines()
	for line in lines:
	    print(line)	
	f.close()
with open("PickleUnpickleTest.txt","a") as f:    
	f.write("\nI am from Bihar")
	f.close()
	
with open("Writetest.txt","w") as f:
    f.write("Hello, Vijay!! Good morning")
    f.close()
	
with open("Writetest.dat","wb") as f:
    l = [10,20,30,40]
    pickle.dump(l,f)
    print("Data dumped into the file successfully")
    f.close()
	
with open("Writetest.dat","rb") as f:
    var = pickle.load(f)
    print("Data read from the file successfully")
    print(var)