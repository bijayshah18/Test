package com.cts.staples.foldercreation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.parasoft.api.Application;
import com.parasoft.api.ExtensionToolContext;
import com.parasoft.data.DataSourceException;

public class FolderCreation {

	public static void createRequestLogfiles(Object input,
			ExtensionToolContext context) throws DataSourceException {
		String reqLogFileLocation = null;
		Application.showMessage(context.toString());

		String datasourceName = context.getValue("DatasourceName");
		String parentDirectory = context.getValue("ParentDirectory");
		String responseFormat = context.getValue("ResponseFormat");
		String testCaseID = context.getValue(datasourceName, "TestCaseID");
		String rowIndex = String.valueOf(context.getDataSourceRowIndex());
		Application.showMessage("DatasourceName: " + datasourceName + ">>>>>" + testCaseID);


		// Code to create the folder directory to store the traffic
		{
			File file = new File(parentDirectory);
			if (!file.exists()) {
				if (file.mkdir()) {
					Application.showMessage("Directory is created!");
				} else {
					Application.showMessage("Failed to create directory!");
				}
			} else {
				Application.showMessage("Directory already exists!");
			}
			reqLogFileLocation = parentDirectory + "\\" + testCaseID + "\\"
					+ "Request\\";
			File files = new File(reqLogFileLocation);
			if (!files.exists()) {
				if (files.mkdirs()) {
					Application.showMessage("Sub folder is created!");
				} else {
					Application.showMessage("Failed to create sub folder!");
				}
			} else {
				Application.showMessage("Folder already exists!");
			}

		}

		// Code to write the request content in the directory
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String formatedDate = sdf.format(new Date());
		String requestFileName = testCaseID + "_" + formatedDate
				+ "_Request_row_" + rowIndex + "." + responseFormat;

		try {

			String requestContent = input.toString();
			File file = new File(reqLogFileLocation + requestFileName);

			// if file does not exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(requestContent);
			bw.close();

			Application.showMessage("Request message written to the file");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void createResponseLogfiles(Object input,
			ExtensionToolContext context) throws DataSourceException {
		String resLogFileLocation = null;
		Application.showMessage(context.toString());

		String datasourceName = context.getValue("DatasourceName");
		String parentDirectory = context.getValue("ParentDirectory");
		String responseFormat = context.getValue("ResponseFormat");
		String rowIndex = String.valueOf(context.getDataSourceRowIndex());
		String testCaseID = context.getValue(datasourceName, "TestCaseID");

		// Code to create the folder directory to store the traffic
		{
			File file = new File(parentDirectory);
			if (!file.exists()) {
				if (file.mkdir()) {
					Application.showMessage("Directory is created!");
				} else {
					Application.showMessage("Failed to create directory!");
				}
			} else {
				Application.showMessage("Directory already exists!");
			}

			resLogFileLocation = parentDirectory + "\\" + testCaseID + "\\"
					+ "Response\\";

			File files = new File(resLogFileLocation);
			if (!files.exists()) {
				if (files.mkdirs()) {
					Application.showMessage("Sub folder is created!");
				} else {
					Application.showMessage("Failed to create sub folder!");
				}
			} else {
				Application.showMessage("Folder already exists!");
			}

		}

		// Code to write the response content in the directory
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String formatedDate = sdf.format(new Date());

		String responseFileName = testCaseID + "_" + formatedDate
				+ "_Response_row_" + rowIndex + "." + responseFormat;

		try {
			String responseContent = input.toString();

			File file = new File(resLogFileLocation + responseFileName);

			// if file does not exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(responseContent);
			bw.close();

			Application.showMessage("Response message written to the file");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
